package com.example.budgetchatbot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BudgetChatbotApplication {

    public static void main(String[] args) {
        SpringApplication.run(BudgetChatbotApplication.class, args);
    }

}
