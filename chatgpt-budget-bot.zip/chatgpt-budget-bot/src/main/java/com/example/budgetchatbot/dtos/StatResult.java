package com.example.budgetchatbot.dtos;

public record StatResult(
        Double avgIncome,
        Double avgRent
) {}