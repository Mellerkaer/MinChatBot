package com.example.budgetchatbot.model;

public class AdminLoginRequest {

    private String password;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}